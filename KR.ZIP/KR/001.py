a = ['asd', 'sdsf', 'sdsf', 'sad', 'sdsf', 'tee', 'sdsf', 'fdg', 'sdsf', 'sdf', 'sdsf']
for i in a:
    if (a.count(i))<2:
        print(i)
