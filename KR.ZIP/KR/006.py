a=[1, 2, 4, 7, 8, 1]
b = [3, 6, 9, 3, 4, 8, 10]
print(len(set(a)), len(set(b)))